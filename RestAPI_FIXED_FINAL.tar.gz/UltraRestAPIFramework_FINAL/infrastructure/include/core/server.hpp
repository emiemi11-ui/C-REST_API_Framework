#pragma once

#include <chrono>
#include "core/master.hpp"
#include "http/router.hpp"

// High-performance Linux-only server:
// - master accepts with epoll
// - workers are fork()ed processes
// - connections are distributed via SCM_RIGHTS FD passing
// - shared memory for global statistics (cross-process)
class Server {
public:
    Server(int port, int num_workers, int threads_per_worker = 8);
    ~Server();

    void start();
    void stop();

    void setRouter(const Router& r);

    // Tuning
    void set_threads_per_worker(int threads);

    // Graceful shutdown support
    void request_shutdown();
    void set_shutdown_timeout(std::chrono::seconds timeout);

private:
    int port_;
    int num_workers_;
    int threads_per_worker_;
    MasterProcess* master_;

    Router router_;
};
