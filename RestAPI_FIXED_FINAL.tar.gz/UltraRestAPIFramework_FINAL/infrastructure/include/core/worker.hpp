#pragma once
#include <string>

class Router;  // forward declaration

namespace Worker {
    void handle_client(int client_fd, Router* router);

    // Exposed for internal reuse / testing
    void send_response(int fd, const std::string& response);

    // Backwards compatibility no-op
    void initialize();
}
