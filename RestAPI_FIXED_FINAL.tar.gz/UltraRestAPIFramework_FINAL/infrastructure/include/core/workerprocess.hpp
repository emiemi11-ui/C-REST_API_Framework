#pragma once

#include <atomic>
#include <sys/types.h>
#include <csignal>

#include "core/threadpool.hpp"
#include "http/router.hpp"
#include "ipc/sharedmemory.hpp"

// Forward declaration for GlobalStats (defined in core/master.hpp)
struct GlobalStats;

class WorkerProcess {
private:
    int worker_id_;
    pid_t pid_;
    int channel_fd_;              // Unix domain socket (recv_fd)
    int threads_per_worker_;

    ThreadPool thread_pool_;
    Router* router_;

    SharedMemory* worker_status_shm_;
    GlobalStats* global_stats_;

    std::atomic<bool> running_{false};

    void setup_signals();
    void work_loop();
    void process_request(int client_fd);

public:
    WorkerProcess(int id, Router* r, int channel_fd, int threads_per_worker, SharedMemory* shm);
    ~WorkerProcess();

    void start();  // Runs in worker process (after fork)
    void stop();
};
