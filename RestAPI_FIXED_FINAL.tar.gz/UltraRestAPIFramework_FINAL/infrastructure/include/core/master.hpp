#pragma once

#include <vector>
#include <atomic>
#include <chrono>
#include <string>
#include <sys/epoll.h>
#include <sys/types.h>
#include <csignal>

#include "ipc/sharedmemory.hpp"
#include "http/router.hpp"

#define MAX_EVENTS 64
#define MAX_WORKERS 32

// Structură pentru statistici workers în shared memory
struct WorkerStats {
    pid_t pid;
    std::atomic<uint64_t> requests_handled;
    std::atomic<uint64_t> requests_failed;
    std::atomic<int> status;  // 0=dead, 1=idle, 2=busy
    char last_error[256];
};

// Structură pentru statistici globale în shared memory
struct GlobalStats {
    std::atomic<uint64_t> total_requests;
    std::atomic<uint64_t> total_errors;
    std::atomic<int> active_connections;
    WorkerStats workers[MAX_WORKERS];
};

// Informații despre fiecare worker process (în master)
struct WorkerInfo {
    pid_t pid;
    int status;  // 0=dead, 1=alive
    std::chrono::steady_clock::time_point last_health_check;
};

// MasterProcess: acceptă conexiuni cu epoll și distribuie socket-urile către workeri
// folosind FD passing (SCM_RIGHTS) prin Unix domain socketpair.
// SharedMemory e folosit pentru statistici globale (cross-process).
class MasterProcess {
private:
    int port_;
    int num_workers_;
    int threads_per_worker_;

    int server_fd_;
    int epoll_fd_;

    std::atomic<bool> running_;
    std::atomic<bool> shutdown_requested_;

    Router router_;

    std::vector<WorkerInfo> workers_;
    std::vector<int> worker_channels_;     // master-side sockets (send_fd)
    std::atomic<size_t> rr_index_{0};      // round-robin index

    // Shared stats (shm)
    SharedMemory* worker_status_shm_;
    GlobalStats* global_stats_;
    std::string stats_shm_name_;

    // Timeout pentru graceful shutdown
    std::chrono::seconds shutdown_timeout_{30};

    // Private helpers
    void setup_signals();
    void setup_epoll();
    void create_workers();
    void accept_loop_epoll();
    void distribute_connection(int client_fd);
    void monitor_workers();
    void handle_worker_death(int worker_index);
    void cleanup();

public:
    MasterProcess(int port, int num_workers, int threads_per_worker = 8);
    ~MasterProcess();

    void start();
    void stop();
    void graceful_shutdown();

    void setRouter(const Router& r);
    void set_shutdown_timeout(std::chrono::seconds timeout);
    void set_threads_per_worker(int threads);
};
