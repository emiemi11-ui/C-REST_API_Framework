#pragma once
#include <string>
#include <map>
#include <cstdint>

class HttpRequest {
public:
    // Start line
    std::string method;   // "GET", "POST", ...
    std::string target;   // "/path?query=1"
    std::string path;     // "/path" (for routing, no query string)

    // Headers + body
    std::map<std::string, std::string> headers;
    std::string body;

    // Full raw request (optional)
    std::string raw;

    // Remote peer (best-effort; set by Worker)
    std::string remote_ip;
    uint16_t remote_port{0};

    const std::string& getMethod() const { return method; }
    const std::string& getTarget() const { return target; }
    const std::string& getPath()   const { return path;   }
};
