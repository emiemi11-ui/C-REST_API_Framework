#pragma once

#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>

namespace ipc {

// Send a file descriptor over a Unix domain socket.
// Returns true on success, false on failure (errno is set).
inline bool send_fd(int unix_sock, int fd_to_send) {
    if (unix_sock < 0 || fd_to_send < 0) {
        errno = EINVAL;
        return false;
    }

    char dummy = 'F';
    struct iovec io;
    io.iov_base = &dummy;
    io.iov_len = sizeof(dummy);

    alignas(struct cmsghdr) unsigned char cmsgbuf[CMSG_SPACE(sizeof(int))];
    std::memset(cmsgbuf, 0, sizeof(cmsgbuf));

    struct msghdr msg;
    std::memset(&msg, 0, sizeof(msg));
    msg.msg_iov = &io;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsgbuf;
    msg.msg_controllen = sizeof(cmsgbuf);

    struct cmsghdr* cmsg = CMSG_FIRSTHDR(&msg);
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    cmsg->cmsg_len = CMSG_LEN(sizeof(int));
    std::memcpy(CMSG_DATA(cmsg), &fd_to_send, sizeof(int));
    msg.msg_controllen = CMSG_SPACE(sizeof(int));

    const ssize_t n = ::sendmsg(unix_sock, &msg, 0);
    return n == static_cast<ssize_t>(sizeof(dummy));
}

// Receive a file descriptor over a Unix domain socket.
// Returns the received fd on success, or -1 on failure (errno is set).
inline int recv_fd(int unix_sock) {
    if (unix_sock < 0) {
        errno = EINVAL;
        return -1;
    }

    char dummy = 0;
    struct iovec io;
    io.iov_base = &dummy;
    io.iov_len = sizeof(dummy);

    alignas(struct cmsghdr) unsigned char cmsgbuf[CMSG_SPACE(sizeof(int))];
    std::memset(cmsgbuf, 0, sizeof(cmsgbuf));

    struct msghdr msg;
    std::memset(&msg, 0, sizeof(msg));
    msg.msg_iov = &io;
    msg.msg_iovlen = 1;
    msg.msg_control = cmsgbuf;
    msg.msg_controllen = sizeof(cmsgbuf);

    const ssize_t n = ::recvmsg(unix_sock, &msg, 0);
    if (n <= 0) {
        return -1;
    }

    struct cmsghdr* cmsg = CMSG_FIRSTHDR(&msg);
    if (!cmsg || cmsg->cmsg_level != SOL_SOCKET || cmsg->cmsg_type != SCM_RIGHTS) {
        errno = EPROTO;
        return -1;
    }

    int fd = -1;
    std::memcpy(&fd, CMSG_DATA(cmsg), sizeof(int));
    return fd;
}

} // namespace ipc
