#pragma once

#include "ipc/sharedmemory.hpp"
#include "sync/semaphore.hpp"

#include <cstddef>
#include <cstring>
#include <chrono>
#include <stdexcept>
#include <type_traits>

// SharedQueue<T> implemented in POSIX shared memory + named semaphores.
// - mutex_   : protects header + ring buffer metadata
// - items_   : counts available elements
// - spaces_  : counts free slots
//
// NOTE: T must be trivially copyable (stored in shared memory as raw bytes).
template<typename T>
class SharedQueue {
    static_assert(std::is_trivially_copyable<T>::value,
                  "SharedQueue<T> requires T to be trivially copyable");

private:
    struct Header {
        size_t head;
        size_t tail;
        size_t size;
        size_t capacity;
    };

    std::string base_name_;
    SharedMemory shm_;
    Header* header_;
    T* buffer_;

    Semaphore mutex_;
    Semaphore items_;
    Semaphore spaces_;

    size_t total_bytes(size_t capacity) const {
        return sizeof(Header) + capacity * sizeof(T);
    }

    void lock()   { mutex_.wait(); }
    void unlock() { mutex_.post(); }

public:
    SharedQueue(const std::string& name, size_t capacity = 1024, bool create = true)
        : base_name_(name),
          shm_(name, total_bytes(capacity), create),
          header_(reinterpret_cast<Header*>(shm_.get_ptr())),
          buffer_(reinterpret_cast<T*>(reinterpret_cast<char*>(shm_.get_ptr()) + sizeof(Header))),
          mutex_(name + "_mtx", 1),
          items_(name + "_items", 0),
          spaces_(name + "_spaces", static_cast<unsigned int>(capacity)) {

        if (create) {
            // Initialize queue header in shared memory
            lock();
            header_->head = 0;
            header_->tail = 0;
            header_->size = 0;
            header_->capacity = capacity;
            unlock();
        }
    }

    // Blocking enqueue
    void enqueue(const T& element) {
        // Wait for space
        spaces_.wait();

        lock();
        const size_t cap = header_->capacity;
        buffer_[header_->tail] = element;
        header_->tail = (header_->tail + 1) % cap;
        header_->size++;
        unlock();

        items_.post();
    }

    // Timed enqueue
    bool enqueue_for(const T& element, std::chrono::milliseconds timeout) {
        if (!spaces_.wait_for(timeout)) return false;

        lock();
        const size_t cap = header_->capacity;
        buffer_[header_->tail] = element;
        header_->tail = (header_->tail + 1) % cap;
        header_->size++;
        unlock();

        items_.post();
        return true;
    }

    // Blocking dequeue
    T dequeue() {
        items_.wait();

        lock();
        const size_t cap = header_->capacity;
        T element = buffer_[header_->head];
        header_->head = (header_->head + 1) % cap;
        header_->size--;
        unlock();

        spaces_.post();
        return element;
    }

    // Timed dequeue
    bool dequeue_for(T& out, std::chrono::milliseconds timeout) {
        if (!items_.wait_for(timeout)) return false;

        lock();
        const size_t cap = header_->capacity;
        out = buffer_[header_->head];
        header_->head = (header_->head + 1) % cap;
        header_->size--;
        unlock();

        spaces_.post();
        return true;
    }

    bool try_dequeue(T& out) {
        if (!items_.try_wait()) return false;

        lock();
        const size_t cap = header_->capacity;
        out = buffer_[header_->head];
        header_->head = (header_->head + 1) % cap;
        header_->size--;
        unlock();

        spaces_.post();
        return true;
    }

    bool is_empty() {
        lock();
        bool empty = (header_->size == 0);
        unlock();
        return empty;
    }

    bool is_full() {
        lock();
        bool full = (header_->size >= header_->capacity);
        unlock();
        return full;
    }

    size_t size() {
        lock();
        size_t s = header_->size;
        unlock();
        return s;
    }

    size_t capacity() {
        lock();
        size_t c = header_->capacity;
        unlock();
        return c;
    }
};
