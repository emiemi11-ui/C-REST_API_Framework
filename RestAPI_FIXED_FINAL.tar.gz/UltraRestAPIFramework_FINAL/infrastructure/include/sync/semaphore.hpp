#pragma once

#include <string>
#include <semaphore.h>
#include <chrono>

class Semaphore {
private:
    std::string name_;
    sem_t* sem_;
    bool owner_;

public:
    explicit Semaphore(const std::string& name, unsigned int initial_value = 1);
    ~Semaphore();

    Semaphore(const Semaphore&) = delete;
    Semaphore& operator=(const Semaphore&) = delete;

    void wait();
    bool try_wait();
    bool wait_for(std::chrono::milliseconds timeout);
    void post();

    sem_t* native_handle() const { return sem_; }
};
