#include "sync/semaphore.hpp"
#include <fcntl.h>
#include <iostream>
#include <stdexcept>
#include <cerrno>
#include <cstring>
#include <ctime>

static std::string normalize_sem_name(std::string name) {
    if (name.empty()) return "/unnamed_sem";
    if (name.front() != '/') name = "/" + name;
    return name;
}

Semaphore::Semaphore(const std::string& raw_name, unsigned int initial_value)
    : name_(normalize_sem_name(raw_name)), sem_(SEM_FAILED), owner_(false) {

    // Try exclusive create first (detect ownership)
    sem_ = sem_open(name_.c_str(), O_CREAT | O_EXCL, 0644, initial_value);
    if (sem_ != SEM_FAILED) {
        owner_ = true;
        std::cout << "[Semaphore] Created named: " << name_ << " (value=" << initial_value << ")\n";
        return;
    }

    if (errno != EEXIST) {
        throw std::runtime_error(std::string("sem_open (create) failed: ") + std::strerror(errno));
    }

    // Already exists => open existing
    sem_ = sem_open(name_.c_str(), 0);
    if (sem_ == SEM_FAILED) {
        throw std::runtime_error(std::string("sem_open (open) failed: ") + std::strerror(errno));
    }

    std::cout << "[Semaphore] Opened named: " << name_ << "\n";
}

Semaphore::~Semaphore() {
    if (sem_ != SEM_FAILED) {
        sem_close(sem_);
        sem_ = SEM_FAILED;
    }

    if (owner_) {
        sem_unlink(name_.c_str());
    }
}

void Semaphore::wait() {
    while (sem_wait(sem_) == -1) {
        if (errno == EINTR) continue;
        throw std::runtime_error(std::string("sem_wait failed: ") + std::strerror(errno));
    }
}

bool Semaphore::try_wait() {
    int r = sem_trywait(sem_);
    return r == 0;
}

bool Semaphore::wait_for(std::chrono::milliseconds timeout) {
    using namespace std::chrono;

    timespec ts{};
    auto now = system_clock::now();
    auto then = now + timeout;

    auto secs = time_point_cast<seconds>(then);
    ts.tv_sec = secs.time_since_epoch().count();
    ts.tv_nsec = duration_cast<nanoseconds>(then - secs).count();

    while (sem_timedwait(sem_, &ts) == -1) {
        if (errno == EINTR) continue;
        if (errno == ETIMEDOUT) return false;
        throw std::runtime_error(std::string("sem_timedwait failed: ") + std::strerror(errno));
    }
    return true;
}

void Semaphore::post() {
    if (sem_post(sem_) == -1) {
        throw std::runtime_error(std::string("sem_post failed: ") + std::strerror(errno));
    }
}
