#include "ipc/sharedmemory.hpp"

#include <iostream>
#include <stdexcept>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

static std::string normalize_shm_name(std::string name) {
    if (name.empty()) return "/unnamed_shm";
    if (name.front() != '/') name = "/" + name;
    return name;
}

SharedMemory::SharedMemory(const std::string& raw_name, size_t size, bool creator)
    : name(normalize_shm_name(raw_name)), size(size), fd(-1), ptr(nullptr), is_creator(creator)
{
    // Step 1: Create or open
    if (creator) {
        fd = shm_open(name.c_str(), O_CREAT | O_RDWR, 0666);
    } else {
        fd = shm_open(name.c_str(), O_RDWR, 0666);
    }

    if (fd == -1)
        throw std::runtime_error("Nu pot deschide shared memory: " + name);

    // Step 2: Set size (creator only)
    if (creator) {
        if (ftruncate(fd, size) == -1)
            throw std::runtime_error("Nu pot seta dimensiunea shared memory: " + name);
    }

    // Step 3: mmap
    ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED) {
        close(fd);
        if (creator) shm_unlink(name.c_str());
        throw std::runtime_error("Nu pot mapa shared memory: " + name);
    }

    std::cout << "[SharedMemory] " << (creator ? "Creata" : "Deschisa")
              << ": " << name << ", " << size << " bytes\n";
}

SharedMemory::~SharedMemory() {
    if (ptr && ptr != MAP_FAILED)
        munmap(ptr, size);

    if (fd != -1)
        close(fd);

    if (is_creator) {
        shm_unlink(name.c_str());
        std::cout << "[SharedMemory] Stearsa: " << name << "\n";
    }
}
