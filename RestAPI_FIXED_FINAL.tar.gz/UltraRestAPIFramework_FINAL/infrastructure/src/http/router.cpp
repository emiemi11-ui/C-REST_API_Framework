#include "http/router.hpp"
#include <iostream>
#include <sstream>

void Router::addRoute(const std::string& method, const std::string& pattern, RouteHandler handler) {
    routes.push_back({method, pattern, handler});
    std::cout << "Added route: " << method << " " << pattern << "\n";
}

std::string Router::handle(const HttpRequest& request) {
    std::cout << "Processing: " << request.method << " " << request.path << "\n";

    for (const auto& route : routes) {
        if (route.method != request.method) continue;

        std::map<std::string, std::string> params;
        if (matchPattern(route.pattern, request.path, params)) {
            std::cout << "Found: " << route.pattern << "\n";
            try {
                return route.handler(request, params);
            } catch (const std::exception& e) {
                std::cerr << "Handler error: " << e.what() << "\n";
                std::string body = std::string("{\"error\":\"") + e.what() + "\"}";

                std::ostringstream response;
                response << "HTTP/1.1 500 Internal Server Error\r\n";
                response << "Content-Type: application/json\r\n";
                response << "Content-Length: " << body.size() << "\r\n";
                response << "Connection: close\r\n\r\n";
                response << body;
                return response.str();
            }
        }
    }

    std::cout << "No route for " << request.method << " " << request.path << "\n";
    std::string body = std::string("{\"error\":\"Not Found\",\"path\":\"") + request.path + "\"}";

    std::ostringstream response;
    response << "HTTP/1.1 404 Not Found\r\n";
    response << "Content-Type: application/json\r\n";
    response << "Content-Length: " << body.size() << "\r\n";
    response << "Connection: close\r\n\r\n";
    response << body;
    return response.str();
}

// Supported patterns:
//   /fixed/path
//   /users/:id
//   /static/*               (single-segment wildcard)
//   /static/:path*          (catch-all; must be last segment; captures remainder into param "path")
bool Router::matchPattern(const std::string& pattern, const std::string& path,
                          std::map<std::string, std::string>& params) {
    if (pattern == "*" || pattern == "/*") {
        return true;
    }

    std::vector<std::string> p = splitPath(pattern);
    std::vector<std::string> s = splitPath(path);

    size_t pi = 0;
    size_t si = 0;

    while (pi < p.size()) {
        const std::string& seg = p[pi];

        if (seg == "*") {
            // single segment wildcard
            if (si >= s.size()) return false;
            ++pi;
            ++si;
            continue;
        }

        if (!seg.empty() && seg[0] == ':') {
            // parameter
            if (seg.size() >= 2 && seg.back() == '*') {
                // catch-all param (must be last pattern segment)
                std::string name = seg.substr(1, seg.size() - 2);
                std::string remainder;

                for (size_t k = si; k < s.size(); ++k) {
                    if (!remainder.empty()) remainder += "/";
                    remainder += s[k];
                }
                params[name] = remainder;
                return true; // catch-all consumes the rest
            }

            if (si >= s.size()) return false;
            std::string name = seg.substr(1);
            params[name] = s[si];
            ++pi;
            ++si;
            continue;
        }

        // literal segment
        if (si >= s.size()) return false;
        if (seg != s[si]) return false;

        ++pi;
        ++si;
    }

    // All pattern segments consumed => match only if path also consumed
    return si == s.size();
}

std::vector<std::string> Router::splitPath(const std::string& path) {
    std::vector<std::string> parts;
    std::string current;

    for (char c : path) {
        if (c == '/') {
            if (!current.empty()) {
                parts.push_back(current);
                current.clear();
            }
        } else {
            current += c;
        }
    }

    if (!current.empty()) {
        parts.push_back(current);
    }

    return parts;
}
