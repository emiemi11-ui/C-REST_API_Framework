#include "core/master.hpp"
#include "core/workerprocess.hpp"
#include "ipc/fd_passing.hpp"

#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <cstring>
#include <iostream>
#include <thread>

// Signal handler global pentru graceful shutdown
static volatile sig_atomic_t graceful_shutdown_requested = 0;

static void signal_handler(int signum) {
    if (signum == SIGTERM || signum == SIGINT) {
        graceful_shutdown_requested = 1;
    }
}

MasterProcess::MasterProcess(int port, int num_workers, int threads_per_worker)
    : port_(port),
      num_workers_(num_workers),
      threads_per_worker_(threads_per_worker),
      server_fd_(-1),
      epoll_fd_(-1),
      running_(false),
      shutdown_requested_(false),
      worker_status_shm_(nullptr),
      global_stats_(nullptr) {

    if (num_workers_ > MAX_WORKERS) {
        num_workers_ = MAX_WORKERS;
    }
    if (threads_per_worker_ <= 0) {
        threads_per_worker_ = 8;
    }

    // Use unique SHM name per port (allows multiple instances)
    stats_shm_name_ = "/rest_api_stats_" + std::to_string(port_);
}

MasterProcess::~MasterProcess() {
    stop();
    cleanup();
}

void MasterProcess::setRouter(const Router& r) {
    router_ = r;
}

void MasterProcess::set_shutdown_timeout(std::chrono::seconds timeout) {
    shutdown_timeout_ = timeout;
}

void MasterProcess::set_threads_per_worker(int threads) {
    if (threads > 0) {
        threads_per_worker_ = threads;
    }
}

void MasterProcess::setup_signals() {
    struct sigaction sa;
    sa.sa_handler = signal_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);

    // Ignore SIGPIPE (broken pipe când client se deconectează)
    signal(SIGPIPE, SIG_IGN);

    std::cout << "> Signal handlers configured\n";
}

void MasterProcess::setup_epoll() {
    epoll_fd_ = epoll_create1(0);
    if (epoll_fd_ == -1) {
        perror("epoll_create1");
        throw std::runtime_error("Failed to create epoll instance");
    }

    struct epoll_event ev;
    ev.events = EPOLLIN | EPOLLET;  // Edge-triggered
    ev.data.fd = server_fd_;

    if (epoll_ctl(epoll_fd_, EPOLL_CTL_ADD, server_fd_, &ev) == -1) {
        perror("epoll_ctl");
        close(epoll_fd_);
        epoll_fd_ = -1;
        throw std::runtime_error("Failed to add server_fd to epoll");
    }

    std::cout << "> epoll configured for non-blocking accept\n";
}

void MasterProcess::start() {
    // 1. Create TCP socket
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ < 0) {
        perror("socket");
        return;
    }

    // Socket options
    int opt = 1;
    if (setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt");
    }

    // Non-blocking accept
    int flags = fcntl(server_fd_, F_GETFL, 0);
    fcntl(server_fd_, F_SETFL, flags | O_NONBLOCK);

    // 2. Bind & listen
    struct sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port_);

    if (bind(server_fd_, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_fd_);
        server_fd_ = -1;
        return;
    }

    if (listen(server_fd_, 1024) < 0) {
        perror("listen");
        close(server_fd_);
        server_fd_ = -1;
        return;
    }

    std::cout << "> Socket listening on port " << port_ << "\n";

    // 3. Setup signals
    setup_signals();

    // 4. Shared stats SHM
    try {
        worker_status_shm_ = new SharedMemory(stats_shm_name_, sizeof(GlobalStats), true);
        global_stats_ = reinterpret_cast<GlobalStats*>(worker_status_shm_->get_ptr());

        global_stats_->total_requests = 0;
        global_stats_->total_errors = 0;
        global_stats_->active_connections = 0;

        for (int i = 0; i < MAX_WORKERS; i++) {
            global_stats_->workers[i].pid = 0;
            global_stats_->workers[i].requests_handled = 0;
            global_stats_->workers[i].requests_failed = 0;
            global_stats_->workers[i].status = 0;
            std::memset(global_stats_->workers[i].last_error, 0, 256);
        }

        std::cout << "> SharedMemory created for statistics: " << stats_shm_name_ << "\n";
    } catch (const std::exception& e) {
        std::cerr << "> Failed to create SharedMemory: " << e.what() << "\n";
        close(server_fd_);
        server_fd_ = -1;
        return;
    }

    // 5. Setup epoll
    setup_epoll();

    // 6. Fork workers
    create_workers();

    // 7. Start accept loop
    running_ = true;
    std::cout << "> Starting on port " << port_
              << " with " << num_workers_ << " workers"
              << " (" << threads_per_worker_ << " threads/worker)\n";

    accept_loop_epoll();

    // If accept loop exits, ensure shutdown
    if (graceful_shutdown_requested) {
        graceful_shutdown();
    }
}

void MasterProcess::create_workers() {
    workers_.assign(num_workers_, WorkerInfo{});
    worker_channels_.assign(num_workers_, -1);

    for (int i = 0; i < num_workers_; i++) {
        int sv[2];
        if (socketpair(AF_UNIX, SOCK_DGRAM, 0, sv) < 0) {
            perror("socketpair");
            continue;
        }

        std::cout << "> Forking worker " << i << "...\n";
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            close(sv[0]);
            close(sv[1]);
            continue;
        }

        if (pid == 0) {
            // ===== CHILD (WORKER) =====
            // Close master side of channel
            close(sv[0]);

            // Important: close inherited master-side channels (FD leak prevention)
            for (int fd : worker_channels_) {
                if (fd >= 0) close(fd);
            }

            // Worker doesn't need accept loop FDs
            if (epoll_fd_ >= 0) close(epoll_fd_);
            if (server_fd_ >= 0) close(server_fd_);

            std::cout << "[Worker " << i << "] PID=" << getpid()
                      << " started (parent PID=" << getppid() << ")\n";

            // Update global stats
            if (global_stats_) {
                global_stats_->workers[i].pid = getpid();
                global_stats_->workers[i].status = 1; // idle
            }

            // Run worker process loop
            WorkerProcess worker(i, &router_, sv[1], threads_per_worker_, worker_status_shm_);
            worker.start();

            close(sv[1]);
            std::cout << "[Worker " << i << "] PID=" << getpid() << " exiting\n";
            _exit(0);
        }

        // ===== PARENT (MASTER) =====
        close(sv[1]); // close worker side

        worker_channels_[i] = sv[0];
        workers_[i].pid = pid;
        workers_[i].status = 1;
        workers_[i].last_health_check = std::chrono::steady_clock::now();

        if (global_stats_) {
            global_stats_->workers[i].pid = pid;
            global_stats_->workers[i].status = 1;
        }

        std::cout << "> Worker " << i << " forked with PID=" << pid << "\n";
    }
}

void MasterProcess::accept_loop_epoll() {
    struct epoll_event events[MAX_EVENTS];

    while (running_ && !graceful_shutdown_requested) {
        int n = epoll_wait(epoll_fd_, events, MAX_EVENTS, 1000);
        if (n < 0) {
            if (errno == EINTR) continue;
            perror("epoll_wait");
            break;
        }

        for (int i = 0; i < n; i++) {
            if (events[i].data.fd != server_fd_) continue;

            // Accept all available connections (edge-triggered)
            while (true) {
                struct sockaddr_in client_addr;
                socklen_t client_len = sizeof(client_addr);

                int client_fd = accept(server_fd_, (struct sockaddr*)&client_addr, &client_len);
                if (client_fd < 0) {
                    if (errno == EAGAIN || errno == EWOULDBLOCK) break;
                    if (errno == EINTR) continue;
                    perror("accept");
                    break;
                }

                distribute_connection(client_fd);
            }
        }

        static int monitor_counter = 0;
        if (++monitor_counter >= 10) { // ~10s
            monitor_workers();
            monitor_counter = 0;
        }
    }
}

void MasterProcess::distribute_connection(int client_fd) {
    // Find next alive worker in round-robin
    int chosen = -1;
    for (int attempt = 0; attempt < num_workers_; ++attempt) {
        size_t idx = rr_index_.fetch_add(1) % static_cast<size_t>(num_workers_);
        if (workers_[idx].status == 1 && worker_channels_[idx] >= 0) {
            chosen = static_cast<int>(idx);
            break;
        }
    }

    if (chosen < 0) {
        std::cerr << "> No alive workers available. Closing connection.\n";
        close(client_fd);
        if (global_stats_) global_stats_->total_errors++;
        return;
    }

    // Send FD to chosen worker
    if (!ipc::send_fd(worker_channels_[chosen], client_fd)) {
        std::cerr << "> Failed to send FD to worker " << chosen
                  << " (errno=" << errno << " " << std::strerror(errno) << ")\n";
        close(client_fd);
        if (global_stats_) global_stats_->total_errors++;
        return;
    }

    // Master closes its copy (worker now owns a duplicate)
    close(client_fd);

    if (global_stats_) {
        global_stats_->total_requests++;
        global_stats_->active_connections++;
    }
}

void MasterProcess::monitor_workers() {
    for (int i = 0; i < num_workers_; i++) {
        if (workers_[i].status == 0) continue;

        int status;
        pid_t result = waitpid(workers_[i].pid, &status, WNOHANG);
        if (result > 0) {
            std::cerr << "> Worker " << i << " (PID " << workers_[i].pid << ") died. Restarting...\n";
            handle_worker_death(i);
        }
    }
}

void MasterProcess::handle_worker_death(int worker_index) {
    if (!running_ || shutdown_requested_) return;

    workers_[worker_index].status = 0;
    if (global_stats_) global_stats_->workers[worker_index].status = 0;

    // Close old channel
    if (worker_channels_[worker_index] >= 0) {
        close(worker_channels_[worker_index]);
        worker_channels_[worker_index] = -1;
    }

    // Create a new channel for restarted worker
    int sv[2];
    if (socketpair(AF_UNIX, SOCK_DGRAM, 0, sv) < 0) {
        perror("socketpair");
        return;
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        close(sv[0]);
        close(sv[1]);
        return;
    }

    if (pid == 0) {
        // ===== CHILD (RESTARTED WORKER) =====
        close(sv[0]);

        // Close inherited master-side channels
        for (int fd : worker_channels_) {
            if (fd >= 0) close(fd);
        }

        if (epoll_fd_ >= 0) close(epoll_fd_);
        if (server_fd_ >= 0) close(server_fd_);

        if (global_stats_) {
            global_stats_->workers[worker_index].pid = getpid();
            global_stats_->workers[worker_index].status = 1;
        }

        WorkerProcess worker(worker_index, &router_, sv[1], threads_per_worker_, worker_status_shm_);
        worker.start();
        close(sv[1]);
        _exit(0);
    }

    // ===== MASTER =====
    close(sv[1]);
    worker_channels_[worker_index] = sv[0];
    workers_[worker_index].pid = pid;
    workers_[worker_index].status = 1;

    if (global_stats_) {
        global_stats_->workers[worker_index].pid = pid;
        global_stats_->workers[worker_index].status = 1;
    }

    std::cout << "> Worker " << worker_index << " restarted with PID=" << pid << "\n";
}

void MasterProcess::stop() {
    if (!running_) return;

    // Request shutdown in the accept loop and trigger graceful shutdown
    running_ = false;
    graceful_shutdown_requested = 1;
    std::cout << "> Stop requested\n";
}

void MasterProcess::graceful_shutdown() {
    if (shutdown_requested_.exchange(true)) return;

    std::cout << "\n> Graceful shutdown initiated\n";

    // Stop accepting new connections
    running_ = false;
    if (server_fd_ >= 0) {
        close(server_fd_);
        server_fd_ = -1;
    }
    if (epoll_fd_ >= 0) {
        close(epoll_fd_);
        epoll_fd_ = -1;
    }

    // Terminate workers
    std::cout << "> Sending SIGTERM to workers...\n";
    for (int i = 0; i < num_workers_; i++) {
        if (workers_[i].status == 1) {
            kill(workers_[i].pid, SIGTERM);
        }
    }

    // Wait for workers to exit (with timeout)
    auto start = std::chrono::steady_clock::now();
    int alive = 0;
    for (int i = 0; i < num_workers_; i++) if (workers_[i].status == 1) alive++;

    while (alive > 0) {
        for (int i = 0; i < num_workers_; i++) {
            if (workers_[i].status != 0) {
                int status;
                pid_t result = waitpid(workers_[i].pid, &status, WNOHANG);
                if (result > 0) {
                    workers_[i].status = 0;
                    alive--;
                }
            }
        }

        auto elapsed = std::chrono::steady_clock::now() - start;
        if (elapsed > shutdown_timeout_) {
            std::cout << "> Shutdown timeout reached. Killing remaining workers...\n";
            for (int i = 0; i < num_workers_; i++) {
                if (workers_[i].status != 0) {
                    kill(workers_[i].pid, SIGKILL);
                    waitpid(workers_[i].pid, nullptr, 0);
                    workers_[i].status = 0;
                }
            }
            break;
        }

        if (alive > 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }

    cleanup();
    std::cout << "> Shutdown complete\n";
}

void MasterProcess::cleanup() {
    // Close channels
    for (int& fd : worker_channels_) {
        if (fd >= 0) {
            close(fd);
            fd = -1;
        }
    }

    // SharedMemory cleanup
    if (worker_status_shm_) {
        delete worker_status_shm_;
        worker_status_shm_ = nullptr;
        global_stats_ = nullptr;
    }
}
