#include "core/workerprocess.hpp"
#include "core/worker.hpp"
#include "core/master.hpp"       // GlobalStats
#include "ipc/fd_passing.hpp"

#include <iostream>
#include <unistd.h>
#include <csignal>
#include <cstring>

// Worker signal flag
static volatile sig_atomic_t worker_shutdown_requested = 0;

static void worker_signal_handler(int signum) {
    if (signum == SIGTERM || signum == SIGINT) {
        worker_shutdown_requested = 1;
    }
}

WorkerProcess::WorkerProcess(int id, Router* r, int channel_fd, int threads_per_worker, SharedMemory* shm)
    : worker_id_(id),
      pid_(getpid()),
      channel_fd_(channel_fd),
      threads_per_worker_(threads_per_worker > 0 ? threads_per_worker : 8),
      router_(r),
      worker_status_shm_(shm),
      global_stats_(nullptr) {

    if (worker_status_shm_) {
        global_stats_ = reinterpret_cast<GlobalStats*>(worker_status_shm_->get_ptr());
    }
}

WorkerProcess::~WorkerProcess() {
    stop();
}

void WorkerProcess::setup_signals() {
    struct sigaction sa;
    sa.sa_handler = worker_signal_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);

    signal(SIGPIPE, SIG_IGN);
}

void WorkerProcess::start() {
    running_ = true;
    setup_signals();

    thread_pool_.init(threads_per_worker_);
    std::cout << "[Worker " << worker_id_ << "] Started with ThreadPool (" << threads_per_worker_ << " threads)\n";

    if (global_stats_) {
        global_stats_->workers[worker_id_].status = 1;  // idle
    }

    work_loop();

    thread_pool_.stop();

    if (global_stats_) {
        global_stats_->workers[worker_id_].status = 0;  // dead
    }

    std::cout << "[Worker " << worker_id_ << "] Stopped\n";
}

void WorkerProcess::work_loop() {
    while (running_ && !worker_shutdown_requested) {
        errno = 0;
        int client_fd = ipc::recv_fd(channel_fd_);

        if (client_fd < 0) {
            if (errno == EINTR) {
                continue;  // interrupted by signal
            }

            // If the master closed the channel, recvmsg() returns 0.
            // We set errno=0 before the call, so errno==0 here means "peer closed".
            if (errno == 0 || errno == EPIPE) {
                break;
            }

            if (worker_shutdown_requested || !running_) break;

            // Small backoff to avoid tight loop on persistent errors
            usleep(1000);
            continue;
        }

        // Dispatch work to thread pool
        thread_pool_.enqueue([this, client_fd]() {
            process_request(client_fd);
        });
    }

    std::cout << "[Worker " << worker_id_ << "] Shutdown signal received, exiting work loop\n";
}

void WorkerProcess::process_request(int client_fd) {
    try {
        if (global_stats_) {
            global_stats_->workers[worker_id_].status = 2; // busy
        }

        Worker::handle_client(client_fd, router_);

        if (global_stats_) {
            global_stats_->workers[worker_id_].requests_handled++;
        }
    } catch (const std::exception& e) {
        std::cerr << "[Worker " << worker_id_ << "] Failed to process request: " << e.what() << "\n";

        if (global_stats_) {
            global_stats_->workers[worker_id_].requests_failed++;
            global_stats_->total_errors++;
            std::strncpy(global_stats_->workers[worker_id_].last_error, e.what(), 255);
        }

        close(client_fd);
    }

    if (global_stats_) {
        global_stats_->active_connections--;
        global_stats_->workers[worker_id_].status = 1; // idle (best-effort)
    }
}

void WorkerProcess::stop() {
    if (!running_) return;
    running_ = false;
}
