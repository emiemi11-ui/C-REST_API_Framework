#include "core/worker.hpp"
#include "http/request.hpp"
#include "http/response.hpp"
#include "http/router.hpp"

#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <vector>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cctype>

namespace Worker {

static constexpr size_t MAX_HEADER_BYTES = 64 * 1024;     // 64KB
static constexpr size_t MAX_BODY_BYTES   = 2 * 1024 * 1024; // 2MB

static inline std::string trim(const std::string& s) {
    size_t b = 0;
    while (b < s.size() && std::isspace(static_cast<unsigned char>(s[b]))) b++;
    size_t e = s.size();
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) e--;
    return s.substr(b, e - b);
}

static inline std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

static bool read_http_request(int fd, std::string& out_raw) {
    out_raw.clear();
    std::vector<char> buf(8192);

    // Read headers first
    while (true) {
        ssize_t n = ::recv(fd, buf.data(), buf.size(), 0);
        if (n < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (n == 0) return false; // client closed
        out_raw.append(buf.data(), static_cast<size_t>(n));

        if (out_raw.size() > MAX_HEADER_BYTES) {
            return false;
        }

        if (out_raw.find("\r\n\r\n") != std::string::npos) {
            break;
        }
    }

    // Parse Content-Length (if any)
    size_t header_end = out_raw.find("\r\n\r\n");
    std::string header_part = out_raw.substr(0, header_end);
    std::string body_part   = out_raw.substr(header_end + 4);

    size_t content_length = 0;
    {
        std::istringstream iss(header_part);
        std::string line;
        // skip request line
        std::getline(iss, line);
        while (std::getline(iss, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            if (line.empty()) break;

            auto colon = line.find(':');
            if (colon == std::string::npos) continue;
            std::string key = to_lower(trim(line.substr(0, colon)));
            std::string val = trim(line.substr(colon + 1));

            if (key == "content-length") {
                try {
                    content_length = static_cast<size_t>(std::stoul(val));
                } catch (...) {
                    content_length = 0;
                }
                break;
            }
        }
    }

    if (content_length > MAX_BODY_BYTES) {
        return false;
    }

    // Read remaining body (if needed)
    while (body_part.size() < content_length) {
        ssize_t n = ::recv(fd, buf.data(), buf.size(), 0);
        if (n < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (n == 0) break;
        out_raw.append(buf.data(), static_cast<size_t>(n));
        body_part.append(buf.data(), static_cast<size_t>(n));
        if (out_raw.size() > (MAX_HEADER_BYTES + MAX_BODY_BYTES)) {
            return false;
        }
    }

    return true;
}

static HttpRequest parse_http_request(const std::string& raw) {
    HttpRequest req;
    req.raw = raw;

    size_t header_end = raw.find("\r\n\r\n");
    std::string header_part = (header_end == std::string::npos) ? raw : raw.substr(0, header_end);
    std::string body_part   = (header_end == std::string::npos) ? std::string() : raw.substr(header_end + 4);

    std::istringstream iss(header_part);
    std::string line;

    // Request line
    if (!std::getline(iss, line)) return req;
    if (!line.empty() && line.back() == '\r') line.pop_back();

    std::istringstream first(line);
    std::string method, target, version;
    if (!(first >> method >> target >> version)) {
        return req;
    }

    req.method = method;
    req.target = target;

    size_t qpos = target.find('?');
    req.path = (qpos == std::string::npos) ? target : target.substr(0, qpos);

    // Headers
    while (std::getline(iss, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty()) break;

        auto colon = line.find(':');
        if (colon == std::string::npos) continue;

        std::string key = to_lower(trim(line.substr(0, colon)));
        std::string val = trim(line.substr(colon + 1));
        req.headers[key] = val;
    }

    req.body = body_part;
    return req;
}

void initialize() {
    // compatibility no-op
}

void send_response(int fd, const std::string& response) {
    // Best-effort send (single-shot)
    ::send(fd, response.data(), response.size(), 0);
}

void handle_client(int client_fd, Router* router) {
    if (!router) {
        ::close(client_fd);
        return;
    }

    // Best-effort timeouts (avoid hanging on slowloris)
    timeval tv{};
    tv.tv_sec = 5;
    tv.tv_usec = 0;
    setsockopt(client_fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(client_fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    // Peer info
    std::string remote_ip;
    uint16_t remote_port = 0;
    sockaddr_in peer{};
    socklen_t peer_len = sizeof(peer);
    if (getpeername(client_fd, reinterpret_cast<sockaddr*>(&peer), &peer_len) == 0) {
        char ipbuf[INET_ADDRSTRLEN];
        if (inet_ntop(AF_INET, &peer.sin_addr, ipbuf, sizeof(ipbuf))) {
            remote_ip = ipbuf;
        }
        remote_port = ntohs(peer.sin_port);
    }

    std::string raw;
    if (!read_http_request(client_fd, raw)) {
        std::string body = R"({"error":"Bad Request"})";
        send_response(client_fd, HttpResponse::json(400, body));
        ::shutdown(client_fd, SHUT_RDWR);
        ::close(client_fd);
        return;
    }

    HttpRequest req = parse_http_request(raw);
    req.remote_ip = remote_ip;
    req.remote_port = remote_port;

    if (req.method.empty() || req.path.empty()) {
        std::string body = R"({"error":"Bad Request"})";
        send_response(client_fd, HttpResponse::json(400, body));
        ::shutdown(client_fd, SHUT_RDWR);
        ::close(client_fd);
        return;
    }

    std::string response = router->handle(req);
    send_response(client_fd, response);

    ::shutdown(client_fd, SHUT_RDWR);
    ::close(client_fd);
}

} // namespace Worker
