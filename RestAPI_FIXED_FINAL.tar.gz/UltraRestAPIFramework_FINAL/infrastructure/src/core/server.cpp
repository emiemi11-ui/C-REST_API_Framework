#include "core/server.hpp"
#include <iostream>

Server::Server(int port, int num_workers, int threads_per_worker)
    : port_(port), num_workers_(num_workers), threads_per_worker_(threads_per_worker), master_(nullptr) {
    master_ = new MasterProcess(port_, num_workers_, threads_per_worker_);
}

Server::~Server() {
    stop();
    if (master_) {
        delete master_;
        master_ = nullptr;
    }
}

void Server::setRouter(const Router& r) {
    router_ = r;
    if (master_) {
        master_->setRouter(router_);
    }
}

void Server::set_threads_per_worker(int threads) {
    threads_per_worker_ = threads;
    if (master_) {
        master_->set_threads_per_worker(threads);
    }
}

void Server::start() {
    if (!master_) {
        std::cerr << "> MasterProcess not initialized!\n";
        return;
    }

    std::cout << "> Starting (epoll + fork workers + FD passing)\n";
    master_->start();
}

void Server::stop() {
    if (master_) {
        master_->stop();
    }
}

void Server::request_shutdown() {
    if (master_) {
        master_->graceful_shutdown();
    }
}

void Server::set_shutdown_timeout(std::chrono::seconds timeout) {
    if (master_) {
        master_->set_shutdown_timeout(timeout);
    }
}
