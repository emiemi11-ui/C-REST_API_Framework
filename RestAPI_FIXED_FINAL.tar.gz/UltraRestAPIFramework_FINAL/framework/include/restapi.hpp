#pragma once

#include <functional>
#include <string>
#include <map>
#include <memory>
#include <algorithm>
#include <cstdint>

namespace RestAPI {

// Forward declarations
class Request;
class Response;
class RestApiFrameworkImpl;

// ===== REQUEST CLASS =====
class Request {
public:
    std::string method;         // GET, POST, PUT, DELETE, OPTIONS
    std::string path;           // /api/resource
    std::string target;         // /api/resource?key=value
    std::string body;           // Request body

    std::map<std::string, std::string> params;   // Path parameters (:id)
    std::map<std::string, std::string> query;    // Query parameters (?key=value)
    std::map<std::string, std::string> headers;  // HTTP headers (stored as lowercase keys)

    std::string raw;            // Raw request (for advanced use)

    // Remote peer (best-effort, set by server)
    std::string remote_ip;
    uint16_t remote_port{0};

    // Helper methods
    const std::string& getMethod() const { return method; }
    const std::string& getPath() const { return path; }
    const std::string& getBody() const { return body; }

    // Get header value (case-insensitive)
    std::string getHeader(const std::string& key) const {
        auto it = headers.find(key);
        if (it != headers.end()) return it->second;

        std::string lower = key;
        std::transform(lower.begin(), lower.end(), lower.begin(),
                       [](unsigned char c){ return static_cast<char>(std::tolower(c)); });

        it = headers.find(lower);
        return (it != headers.end()) ? it->second : "";
    }

    // Get query parameter
    std::string getQuery(const std::string& key) const {
        auto it = query.find(key);
        return (it != query.end()) ? it->second : "";
    }

    // Get path parameter
    std::string getParam(const std::string& key) const {
        auto it = params.find(key);
        return (it != params.end()) ? it->second : "";
    }
};

// ===== RESPONSE CLASS =====
class Response {
public:
    int status;
    std::string body;
    std::map<std::string, std::string> headers;

    Response() : status(200) {}
    Response(int s, const std::string& b) : status(s), body(b) {}

    // Static factory methods
    static Response json(int status, const std::string& data) {
        Response r(status, data);
        r.headers["Content-Type"] = "application/json";
        return r;
    }

    static Response text(int status, const std::string& data) {
        Response r(status, data);
        r.headers["Content-Type"] = "text/plain";
        return r;
    }

    static Response html(int status, const std::string& data) {
        Response r(status, data);
        r.headers["Content-Type"] = "text/html";
        return r;
    }

    static Response binary(int status, const std::string& data, const std::string& mime) {
        Response r(status, data);
        r.headers["Content-Type"] = mime;
        return r;
    }

    // Set custom header
    Response& setHeader(const std::string& key, const std::string& value) {
        headers[key] = value;
        return *this;
    }
};

// Type aliases for handler functions
using RouteHandler = std::function<Response(const Request&)>;
using MiddlewareHandler = std::function<bool(Request&, Response&)>;

// ===== MAIN FRAMEWORK CLASS =====
class RestApiFramework {
public:
    // Constructor
    explicit RestApiFramework(int port = 8080, int workers = 4);

    // Destructor
    ~RestApiFramework();

    // Delete copy constructor and assignment operator (non-copyable)
    RestApiFramework(const RestApiFramework&) = delete;
    RestApiFramework& operator=(const RestApiFramework&) = delete;

    // ===== ROUTE REGISTRATION =====

    void get(const std::string& path, RouteHandler handler);
    void post(const std::string& path, RouteHandler handler);
    void put(const std::string& path, RouteHandler handler);
    void del(const std::string& path, RouteHandler handler);

    // ===== MIDDLEWARE =====
    void use(MiddlewareHandler middleware);

    // ===== STATIC FILES =====
    void serve_static(const std::string& route, const std::string& directory);

    // ===== SERVER CONTROL =====
    void start();      // blocking
    void stop();
    void shutdown();   // graceful

    // ===== CONFIGURATION =====
    void set_workers(int count);
    void set_thread_pool_size(int size);           // threads per worker
    void enable_cors(bool enable = true);
    void set_cors_origins(const std::string& origins);
    void enable_logging(const std::string& log_file = "server.log");
    void set_log_level(int level);                 // 0=ERROR, 1=WARN, 2=INFO, 3=DEBUG
    void set_shutdown_timeout(int seconds);

    int get_port() const;
    int get_workers() const;

private:
    std::unique_ptr<RestApiFrameworkImpl> pImpl;
};

} // namespace RestAPI
