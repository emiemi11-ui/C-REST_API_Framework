#include "restapi.hpp"

// Infrastructure layer
#include "../../infrastructure/include/core/server.hpp"
#include "../../infrastructure/include/http/router.hpp"
#include "../../infrastructure/include/http/request.hpp"
#include "../../infrastructure/include/http/response.hpp"
#include "../../infrastructure/include/utils/logger.hpp"

#include <iostream>
#include <sstream>
#include <algorithm>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;

namespace RestAPI {

// ===== HELPER FUNCTIONS =====

static std::map<std::string, std::string> parseQuery(const std::string& target) {
    std::map<std::string, std::string> out;
    auto qpos = target.find('?');
    if (qpos == std::string::npos) return out;

    auto q = target.substr(qpos + 1);
    size_t i = 0;
    while (i < q.size()) {
        size_t amp = q.find('&', i);
        std::string pair = (amp == std::string::npos) ? q.substr(i) : q.substr(i, amp - i);
        size_t eq = pair.find('=');
        std::string k = (eq == std::string::npos) ? pair : pair.substr(0, eq);
        std::string v = (eq == std::string::npos) ? "" : pair.substr(eq + 1);
        out[k] = v;
        if (amp == std::string::npos) break;
        i = amp + 1;
    }
    return out;
}

static Request convertRequest(const HttpRequest& httpReq,
                             const std::map<std::string, std::string>& pathParams) {
    Request req;
    req.method = httpReq.method;
    req.path = httpReq.path;
    req.target = httpReq.target;
    req.body = httpReq.body;
    req.headers = httpReq.headers;   // lowercase keys
    req.params = pathParams;
    req.query = parseQuery(httpReq.target);
    req.raw = httpReq.raw;
    req.remote_ip = httpReq.remote_ip;
    req.remote_port = httpReq.remote_port;
    return req;
}

static std::string statusText(int status) {
    switch (status) {
        case 200: return "OK";
        case 201: return "Created";
        case 204: return "No Content";
        case 301: return "Moved Permanently";
        case 302: return "Found";
        case 304: return "Not Modified";
        case 400: return "Bad Request";
        case 401: return "Unauthorized";
        case 403: return "Forbidden";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 413: return "Payload Too Large";
        case 429: return "Too Many Requests";
        case 500: return "Internal Server Error";
        default:  return "Unknown";
    }
}

static std::string convertResponse(const Response& response) {
    std::ostringstream oss;

    oss << "HTTP/1.1 " << response.status << " " << statusText(response.status) << "\r\n";

    // Default headers
    bool has_connection = false;
    bool has_content_length = false;

    for (const auto& [key, value] : response.headers) {
        if (key == "Connection") has_connection = true;
        if (key == "Content-Length") has_content_length = true;
        oss << key << ": " << value << "\r\n";
    }

    if (!has_connection) {
        oss << "Connection: close\r\n";
    }

    if (!has_content_length) {
        oss << "Content-Length: " << response.body.size() << "\r\n";
    }

    oss << "\r\n";
    oss << response.body;

    return oss.str();
}

static std::string guessMime(const std::string& filename) {
    auto ext = fs::path(filename).extension().string();
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c){ return std::tolower(c); });

    if (ext == ".html" || ext == ".htm") return "text/html; charset=utf-8";
    if (ext == ".css")  return "text/css; charset=utf-8";
    if (ext == ".js")   return "application/javascript; charset=utf-8";
    if (ext == ".json") return "application/json; charset=utf-8";
    if (ext == ".txt")  return "text/plain; charset=utf-8";
    if (ext == ".svg")  return "image/svg+xml";
    if (ext == ".png")  return "image/png";
    if (ext == ".jpg" || ext == ".jpeg") return "image/jpeg";
    if (ext == ".gif")  return "image/gif";
    if (ext == ".ico")  return "image/x-icon";
    if (ext == ".woff") return "font/woff";
    if (ext == ".woff2") return "font/woff2";
    if (ext == ".ttf")  return "font/ttf";
    if (ext == ".pdf")  return "application/pdf";
    return "application/octet-stream";
}

static bool isSafeRelativePath(const std::string& rel) {
    if (rel.empty()) return true;
    if (rel.find('\\') != std::string::npos) return false;
    if (!rel.empty() && rel[0] == '/') return false;
    // prevent traversal
    if (rel.find("..") != std::string::npos) return false;
    return true;
}

static bool readFileBinary(const fs::path& p, std::string& out) {
    std::ifstream f(p, std::ios::binary);
    if (!f) return false;
    std::ostringstream ss;
    ss << f.rdbuf();
    out = ss.str();
    return true;
}

// ===== IMPLEMENTATION CLASS =====
class RestApiFrameworkImpl {
public:
    int port;
    int workers;
    int thread_pool_size;

    bool cors_enabled;
    std::string cors_origins;
    bool cors_options_registered{false};

    std::string log_file;
    int log_level;
    int shutdown_timeout;

    Router router;
    std::unique_ptr<Server> server;

    std::vector<MiddlewareHandler> middlewares;

    RestApiFrameworkImpl(int p, int w)
        : port(p)
        , workers(w)
        , thread_pool_size(8)
        , cors_enabled(false)
        , cors_origins("*")
        , log_level(2)
        , shutdown_timeout(30)
    {}

    void ensureCorsOptionsRoute() {
        if (!cors_enabled || cors_options_registered) return;
        cors_options_registered = true;

        registerRoute("OPTIONS", "/:path*", [](const Request& /*req*/) {
            Response r(204, "");
            // body empty; Content-Length should remain 0
            return r;
        });
    }

    void registerRoute(const std::string& method, const std::string& path, RouteHandler handler) {
        auto wrappedHandler = [handler, this](const HttpRequest& httpReq,
                                              const std::map<std::string, std::string>& params) -> std::string {
            Request req = convertRequest(httpReq, params);

            // Fast-path for preflight: skip user middlewares
            if (cors_enabled && req.method == "OPTIONS") {
                Response pre = handler(req);

                pre.setHeader("Access-Control-Allow-Origin", cors_origins);
                pre.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
                pre.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
                pre.setHeader("Access-Control-Max-Age", "600");
                return convertResponse(pre);
            }

            // Execute middlewares
            Response early;
            for (auto& middleware : middlewares) {
                if (!middleware(req, early)) {
                    if (cors_enabled) {
                        early.setHeader("Access-Control-Allow-Origin", cors_origins);
                        early.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
                        early.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
                    }
                    return convertResponse(early);
                }
            }

            // Execute handler
            Response response = handler(req);

            // CORS headers
            if (cors_enabled) {
                response.setHeader("Access-Control-Allow-Origin", cors_origins);
                response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
                response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
            }

            return convertResponse(response);
        };

        router.addRoute(method, path, wrappedHandler);
    }
};

// ===== PUBLIC API =====

RestApiFramework::RestApiFramework(int port, int workers)
    : pImpl(std::make_unique<RestApiFrameworkImpl>(port, workers)) {}

RestApiFramework::~RestApiFramework() {
    if (pImpl && pImpl->server) {
        pImpl->server->stop();
    }
}

void RestApiFramework::get(const std::string& path, RouteHandler handler) {
    pImpl->registerRoute("GET", path, handler);
}

void RestApiFramework::post(const std::string& path, RouteHandler handler) {
    pImpl->registerRoute("POST", path, handler);
}

void RestApiFramework::put(const std::string& path, RouteHandler handler) {
    pImpl->registerRoute("PUT", path, handler);
}

void RestApiFramework::del(const std::string& path, RouteHandler handler) {
    pImpl->registerRoute("DELETE", path, handler);
}

void RestApiFramework::use(MiddlewareHandler middleware) {
    pImpl->middlewares.push_back(middleware);
}

void RestApiFramework::serve_static(const std::string& route, const std::string& directory) {
    std::string prefix = route.empty() ? "/" : route;
    if (prefix.size() > 1 && prefix.back() == '/') {
        prefix.pop_back();
    }

    fs::path base = fs::weakly_canonical(fs::path(directory));

    auto serve = [base](const Request& req, bool head_only) -> Response {
        std::string rel = req.getParam("path");
        if (rel.empty()) rel = "index.html";

        if (!isSafeRelativePath(rel)) {
            return Response::json(403, R"({"error":"Forbidden"})");
        }

        fs::path candidate = base / fs::path(rel).lexically_normal();

        // Ensure still inside base (prevent traversal via symlinks etc.)
        fs::path canon_base = fs::weakly_canonical(base);
        fs::path canon_candidate = fs::weakly_canonical(candidate);

        auto base_str = canon_base.string();
        auto cand_str = canon_candidate.string();
        if (cand_str.size() < base_str.size() || cand_str.compare(0, base_str.size(), base_str) != 0) {
            return Response::json(403, R"({"error":"Forbidden"})");
        }

        if (!fs::exists(canon_candidate)) {
            return Response::json(404, R"({"error":"Not Found"})");
        }

        if (fs::is_directory(canon_candidate)) {
            fs::path idx = canon_candidate / "index.html";
            if (!fs::exists(idx)) {
                return Response::json(404, R"({"error":"Not Found"})");
            }
            canon_candidate = idx;
        }

        std::error_code ec;
        auto sz = fs::file_size(canon_candidate, ec);
        if (ec) sz = 0;

        std::string data;
        if (!head_only) {
            if (!readFileBinary(canon_candidate, data)) {
                return Response::json(500, R"({"error":"Failed to read file"})");
            }
        }

        Response r = Response::binary(200, data, guessMime(canon_candidate.string()));
        r.setHeader("Cache-Control", "public, max-age=60");

        // For HEAD, preserve correct Content-Length
        if (head_only) {
            r.body.clear();
            r.setHeader("Content-Length", std::to_string(sz));
        }

        return r;
    };

    std::string pattern = (prefix == "/") ? "/:path*" : (prefix + "/:path*");

    pImpl->registerRoute("GET", pattern, [serve](const Request& req) { return serve(req, false); });
    pImpl->registerRoute("HEAD", pattern, [serve](const Request& req) { return serve(req, true); });

    std::cout << "[FRAMEWORK] Static files: " << directory << " mounted at " << prefix << "\n";
}

void RestApiFramework::start() {
    // Configure logger if enabled
    if (!pImpl->log_file.empty()) {
        utils::Logger::getInstance().initialize(pImpl->log_file);
        utils::Logger::Level lvl = utils::Logger::Level::INFO;
        switch (pImpl->log_level) {
            case 0: lvl = utils::Logger::Level::ERROR; break;
            case 1: lvl = utils::Logger::Level::WARNING; break;
            case 2: lvl = utils::Logger::Level::INFO; break;
            case 3: lvl = utils::Logger::Level::DEBUG; break;
            default: break;
        }
        utils::Logger::getInstance().setLevel(lvl);
        LOG_INFO("RestApiFramework logging enabled");
    }

    // CORS preflight route
    if (pImpl->cors_enabled) {
        pImpl->ensureCorsOptionsRoute();
    }

    std::cout << "\n=== REST API Server ===\n";
    std::cout << "Starting on port " << pImpl->port << "...\n";
    std::cout << "Workers: " << pImpl->workers << " processes, " << pImpl->thread_pool_size << " threads each\n";
    if (pImpl->cors_enabled) {
        std::cout << "CORS enabled\n";
    }

    pImpl->server = std::make_unique<Server>(pImpl->port, pImpl->workers, pImpl->thread_pool_size);
    pImpl->server->setRouter(pImpl->router);
    pImpl->server->set_shutdown_timeout(std::chrono::seconds(pImpl->shutdown_timeout));

    std::cout << "\nServer ready at http://localhost:" << pImpl->port << "\n";
    pImpl->server->start();
}

void RestApiFramework::stop() {
    if (pImpl && pImpl->server) {
        pImpl->server->stop();
    }
}

void RestApiFramework::shutdown() {
    if (pImpl && pImpl->server) {
        pImpl->server->request_shutdown();
    }
}

void RestApiFramework::set_workers(int count) {
    pImpl->workers = count;
}

void RestApiFramework::set_thread_pool_size(int size) {
    pImpl->thread_pool_size = size;
}

void RestApiFramework::enable_cors(bool enable) {
    pImpl->cors_enabled = enable;
    if (enable) {
        pImpl->ensureCorsOptionsRoute();
    }
}

void RestApiFramework::set_cors_origins(const std::string& origins) {
    pImpl->cors_origins = origins;
}

void RestApiFramework::enable_logging(const std::string& log_file) {
    pImpl->log_file = log_file;
}

void RestApiFramework::set_log_level(int level) {
    pImpl->log_level = level;
}

void RestApiFramework::set_shutdown_timeout(int seconds) {
    pImpl->shutdown_timeout = seconds;
}

int RestApiFramework::get_port() const {
    return pImpl->port;
}

int RestApiFramework::get_workers() const {
    return pImpl->workers;
}

} // namespace RestAPI
