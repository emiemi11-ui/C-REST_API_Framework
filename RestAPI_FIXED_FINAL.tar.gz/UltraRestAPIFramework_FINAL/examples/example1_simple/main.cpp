#include <restapi.hpp>
#include <iostream>

using namespace RestAPI;

int main(int argc, char** argv) {
    int port = 8080;
    int workers = 4;
    int threads_per_worker = 8;

    if (argc > 1) port = std::stoi(argv[1]);
    if (argc > 2) workers = std::stoi(argv[2]);
    if (argc > 3) threads_per_worker = std::stoi(argv[3]);

    RestApiFramework app(port, workers);
    app.set_thread_pool_size(threads_per_worker);
    app.enable_cors(true);

    // Simple health endpoint
    app.get("/health", [](const Request&) {
        return Response::json(200, R"({"status":"ok"})");
    });

    // Hello endpoint
    app.get("/hello/:name", [](const Request& req) {
        std::string name = req.getParam("name");
        return Response::json(200, std::string(R"({"hello":")") + name + R"("})");
    });

    std::cout << "[example1_simple] Usage: " << argv[0] << " [port] [workers] [threads_per_worker]\n";
    app.start();
    return 0;
}
