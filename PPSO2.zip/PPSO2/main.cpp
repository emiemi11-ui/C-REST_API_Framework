#include "server.hpp"
#include "utils.hpp"

int main() 
{
    //curl -X GET http://localhost:8080/users
    //curl -X POST http://localhost:8080/users -d "name=Gabriel"
    //curl -X DELETE http://localhost:8080/users -d "name=Gabriel"
    //curl -X PUT http://localhost:8080/users -d "old=Ana&new=AnaMaria"

    utils::log("Starting REST API Framework...");
    Server server(8080);
    server.start();
    return 0;
}